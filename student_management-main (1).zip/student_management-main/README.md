# Student Management

## Installation
1. Clone this repository
2. Open 2 terminal
3. The first terminal type ``cd client`` => ``npm install`` => ``npm start``
4. The second terminal type ``cd server`` => ``npm install`` => ``npm start``
